<?php 

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    // Specify the connection to use

    // If the table name doesn't follow Laravel's convention
    protected $table = 'products';

    // If the primary key isn't 'id' or isn't auto-incrementing
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';

    // Other model settings and methods
}
